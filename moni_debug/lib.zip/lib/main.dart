import 'package:flutter/material.dart';
import 'package:moni_debug/quiz.dart';

void main() {
  runApp(const Quiz()); // Nyt meidän sovellus on kokonaan Quiz luokan sisällä
} // Täällä _QuizState ei toimi

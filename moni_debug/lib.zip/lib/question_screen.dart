// Luo stateful widget, joka palauttaa Text widgetin tekstillä "Question Screen"

import 'package:flutter/material.dart';

import 'package:moni_debug/answer_button.dart';
import 'package:moni_debug/data/questions.dart';

class QuestionScreen extends StatefulWidget {
  const QuestionScreen(
      {super.key,
      required this.onSelectAnswer,
      required this.currentIndex,
      required this.onRestart,
      required this.onResult});

  final void Function(String answer, BuildContext) onSelectAnswer;
  final Function(int, BuildContext) onRestart;
  final Function(int, BuildContext) onResult;
  final int currentIndex;

  // createState
  @override
  State<QuestionScreen> createState() {
    return _QuestionScreenState();
  }
}

// Luokan nimessä on alaviiva, joten se on yksityinen
// Yksityistä luokkaa voi käyttää vain tämän tiedoston sisäiset koodit
class _QuestionScreenState extends State<QuestionScreen> {
  void answerQuestion(String selectedAnswer) {
    widget.onSelectAnswer(selectedAnswer, context);
    //currentQuestionIndex += 1;
  }

  // build
  @override
  Widget build(context) {
    final currentQuestion = questions[widget.currentIndex];
    if (widget.currentIndex == 5) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
                "You have already answered all of the questions, would you like to restart quiz?",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            TextButton.icon(
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              onPressed: () => widget.onRestart(1, context),
              icon: const Icon(Icons.refresh),
              label: const Text('Restart Quiz!'),
            ),
            const SizedBox(height: 20),
            const Text(
                "You have already answered all of the questions, go see your results!",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            TextButton.icon(
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
              ),
              onPressed: () => widget.onResult(3, context),
              icon: const Icon(Icons.arrow_right_alt),
              label: const Text('Results of the Quiz!'),
            ),
          ],
        ),
      );
    }
    return Center(
      child: Container(
        margin: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              currentQuestion.text,
            ),
            const SizedBox(height: 30),
            // map funktio käy läpi datan listassa, suorittaa funktion jokaista
            // listan itemiä kohden ja tallentaa uuden datan, uuteen listaan.
            // Uusi lista ei näy koodissa, se vain ilmestyy tähän kohtaan, jossa
            // suoritetaan map() funktio.
            ...currentQuestion.shuffledAnswer.map(
              (item) {
                return AnswerButton(
                    answerText: item,
                    onTap: () {
                      answerQuestion(item);
                    });
              },
            )
            // map palauttaa listan, eli:
            // [widget, [widget, widget, widget], widget, widget jne]
            // lista ei kelpaa listaan widgettejä, joten se pitää purkaa
            // ... eli spread operaatio.
          ],
        ),
      ),
    );
  }
}
